

import java.nio.file.Path;
import java.util.*;

import automata.*;
import engine.*;
import tuples.*;


public class Main {
	private static final int indexW = 0;
	private static final int indexU = 1;
	private static final int indexV = 2;
	private static final int indexTMP = 3;
	private static int[] min_cardinal = {-1, -1, -1, -1};
	private static int[] max_cardinal = {-1, -1, -1, -1};
	private static int[] all_cardinal = {0, 0, 0, 0};
	private static int[] nb_iterations = {1, 1, 1, 1};
	private static int call_V = 0;
	
	private static boolean exists_printing_flag, flag_q, flag_v, flag_p, flag_w, flag_t, flag_i, flag_c;
	private static boolean flag_o = true;
	private static long time_start = 0L, time_end = 0L;
	
	private static PostI postI = null, postIrev = null;
	public static String witness = "";
	

	private static ArrayList<String> set_options (String[] args) throws Exception {
		ArrayList<String> files = new ArrayList<>(2);

		for (String arg : args) {
			if (arg.equalsIgnoreCase("-s") || arg.equalsIgnoreCase("--stats"))
				exists_printing_flag = flag_i = flag_t = flag_c = true;
			else if (arg.equalsIgnoreCase("-v") || arg.equalsIgnoreCase("--verbose"))
				exists_printing_flag = flag_v = true;
			else if (arg.equalsIgnoreCase("-c") || arg.equalsIgnoreCase("--card"))
				exists_printing_flag = flag_c = true;
			else if (arg.equalsIgnoreCase("-w") || arg.equalsIgnoreCase("--witness"))
				exists_printing_flag = flag_w = true;
			else if (arg.equalsIgnoreCase("-i") || arg.equalsIgnoreCase("--iter"))
				exists_printing_flag = flag_i = true;
			else if (arg.equalsIgnoreCase("-t") || arg.equalsIgnoreCase("--time"))
				exists_printing_flag = flag_t = true;
			else if (arg.equalsIgnoreCase("-p") || arg.equalsIgnoreCase("--prefix"))
				exists_printing_flag = flag_p = true;
			else if (arg.equalsIgnoreCase("-q") || arg.equalsIgnoreCase("--quiet"))
				flag_q = true;
			else if (arg.equalsIgnoreCase("-o") || arg.equalsIgnoreCase("--optimize"))
				flag_o = true;
			else if (arg.equalsIgnoreCase("-h") || arg.equalsIgnoreCase("--help") || arg.equalsIgnoreCase("-help")) {
				System.out.println("USAGE: java -jar Ignite.jar <SUB Büchi automaton> <SUP Büchi automaton>\n");
				System.out.println("EXIT CODE:\n"
						+ "    0 if the inclusion is TRUE\n"
						+ "    1 if the inclusion is FALSE\n"
						+ "    127 when the inclusion have not been computed\n");
				System.out.println("OPTIONS:");				
				System.out.println("  -v, --verbose (STILL UNDER COMSEPTION)\n    "
						+ "Print the execution steps\n");
				System.out.println("  -q, --quiet\n    "
						+ "Disallows all output prints. "
						+ "Yet, the result is stored in the exit code. "
						+ "This option is ignored when not used alone\n");
				System.out.println("  -t, --time\n    "
						+ "Print the run time (in millisecondes) of the inclusion methode (parsing time excluded)\n");
				System.out.println("  -w, --witness\n    "
						+ "If the inclusion does not holds, print a counter example\n");
				System.out.println("  -i, --iter\n    "
						+ "Print information on the number of iterations performed to reach fix-points. "
						+ "For fix-points over prefixes, it shows the exact number of loops. "
						+ "For fix-points over periods, it shows an average given as the ratio between "
						+ "the iterations of all fix-points and the number of fix-points\n");
				System.out.println("  -c, --card (DOES NOT WORK CORRECTLY)\n    "
						+ "Shows cardinalities of the sets obtained by the subset constructed sets. "
						+ "The information is geven as triplets for the fix-points over minimal prefixes, maximal prefixes and then periodes. "
						+ "The first component is the size of the smallest set of states, "
						+ "the second one the size of the largest set of states "
						+ "and the last component is an average given as the ratio between "
						+ "the sum of set of states size and how many they are\n");
				System.out.println("  -p, --prefix\n    "
						+ "Shows contents of the prefixes maximal and minimal\n");
				System.out.println("  -s, --stats\n    "
						+ "Activate options -i, -t and -c\n");
				System.out.println("  -o, --optimize\n    "
						+ "Activate an optimization that consists to ignore membership queries 'u {v}' "
						+ "for which there is a MAX prefix w such that u < w and wv < w\n");
				System.exit(127);
			} else if (!arg.startsWith("-"))
				files.add(arg);
			else
				throw new Exception("The option " + arg + " is not supported!");
		}

		if (files.size() != 2) throw new Exception("Forqlift needs exactly two Büchi automata!");		
		return files;
	}


	private static void print_options (BuchiAutomaton A) {
		if (flag_i) {
			System.out.print("\n¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨");
			System.out.println("\nITERATIONS TO REACH FIX-POINTS");
			System.out.println("  Prefixes maximal a.k.a. W: " + nb_iterations[indexW]);
			System.out.println("  Prefixes minimal a.k.a. U: " + nb_iterations[indexU]);
			float avg_iteration = (float) nb_iterations[indexV] / (float)call_V;
			System.out.println("           Periods a.k.a. V: " + avg_iteration + " = " + nb_iterations[indexV] + "/" + call_V + " (sum / calls)");
		}
		if (flag_c) {
			extract_cardinals(postI.getCardinals(), indexU);
			extract_cardinals(postIrev.getCardinals(), indexW);
			System.out.print("\n¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨");
			System.out.println("\nCARDINALS OF SETS OF STATES");
			float avg_Ucard = (float) all_cardinal[indexU]  / (float) A.getStates().size();
			float avg_Wcard = (float) all_cardinal[indexW] / (float) A.getStates().size();
			float avg_Vcard = (float) all_cardinal[indexV] / (float) (A.getStates().size() * call_V);
			System.out.println("  Prefixes maximal a.k.a. W"
					+ "\n    smallest: " + min_cardinal[indexW]
					+ "\n    largest: " + max_cardinal[indexW]
					+ "\n    average: " + avg_Wcard + " = sum / cardinal states of A");
			System.out.println("  Prefixes minimal a.k.a. U"
					+ "\n    smallest: " + min_cardinal[indexU]
					+ "\n    largest: " + max_cardinal[indexU]
					+ "\n    average: " + avg_Ucard + " = sum / cardinal states of A");
			System.out.println("  Periods a.k.a. V"
					+ "\n    smallest: " + min_cardinal[indexV]
					+ "\n    largest: " + max_cardinal[indexV]
					+ "\n    average: " + avg_Vcard + " = sum / ( cardinal states of A * nb fix-points )");
		}
		if (flag_p) {
			System.out.print("\n¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨");
			System.out.println("\nMINIMAL PREFIXES");
			for (State s : A.getFinalStates()) {
				System.out.println("\nAt final state " + s);
				for (Pair<SetOfStates, Word> pairU : postI.getSetOfT(s))
					System.out.println("  '" + pairU.getSecond() + "'\n  " + pairU.getFirst() + "\n");
			}
			System.out.print("\n¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨");
			System.out.println("\nMAXIMAL PREFIXES");
			for (State s : A.getFinalStates()) {
				System.out.println("\nAt final state " + s);
				for (Pair<SetOfStates, Word> pairW : postIrev.getSetOfT(s))
					System.out.println("  '" + pairW.getSecond() + "'\n  " + pairW.getFirst() + "\n");
			}
		}
		if (flag_w && witness != "") {
			System.out.print("\n¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨\n");
			System.out.println("NON-INCLUSION WITNESS");
			System.out.println("  " + witness);
		}
		if (flag_t) {
			System.out.print("\n¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨");
			System.out.println("\nTIMING (ms):" + (time_end - time_start));
		}
	}



	public static void main(String[] args) {
		try {
			ArrayList<String> names = set_options(args);
			Path[] files = new Path[2];
			files[0] = Path.of(names.get(0));
			files[1] = Path.of(names.get(1));

			BuchiAutomaton A = new BuchiAutomaton(files[0], new HashSet<>());
			BuchiAutomaton B = new BuchiAutomaton(files[1], A.getAlphabet());

			if (exists_printing_flag) {
				System.out.println("################\n\nFORQLIFT PROGRAM");
				System.out.println("\n¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨\nFILES");
				System.out.println("  sub-automaton:   " + files[0]);
				System.out.println("  super-automaton: " + files[1]);
			}
			

			if (flag_t) time_start = System.currentTimeMillis();
			boolean result = inclusion(A, B);
			if (flag_t) time_end = System.currentTimeMillis();

			print_options(A);
			if (exists_printing_flag) System.out.println("\n¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨\nOUTPUT:" + result + "\n################");
			else if (flag_q == false) System.out.println(result);
			

			System.exit(result?0:1);
		}
		catch (Exception e) {
			System.out.println("\nERROR\n  " + e.getMessage() + "\n");
			System.exit(127);
		}
	}




	public static boolean inclusion (BuchiAutomaton A, BuchiAutomaton B) {
		if (flag_v) System.out.println("\n¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨\nINCLUSION");
		
		
		if (flag_v) System.out.print("  MAX prefixes fix-point: computing ..\r");
		postIrev = new PostI(A.getInitialState(), B.getInitialState(), true);
		while (postIrev.apply()) nb_iterations[indexW]++;
		if (flag_v) System.out.println("  MAX prefixes fix-point: done (" + nb_iterations[indexW] + " iterations, " +postIrev.size()+ " elements)");
		
		
		if (flag_v) System.out.print("  MIN prefixes fix-point: computing ..\r");
		postI = new PostI(A.getInitialState(), B.getInitialState(), false);
		while (postI.apply()) nb_iterations[indexU]++;
		if (flag_v) System.out.println("  MIN prefixes fix-point: done (" + nb_iterations[indexU] + " iterations, " +postI.size()+ " elements)");
		
		
		int final_counter=0;
		int membership_counter=0;
		call_V=0;
		for (State s : A.getFinalStates()) {final_counter++;
			if (flag_v) System.out.println("  FINAL STATE '"+s.getName()+"' ("+final_counter+"/"+A.getFinalStates().size()+")");
			
			int max_counter=0;
			for (Pair<SetOfStates, Word> pairW : postIrev.getSetOfT(s)) {call_V++;max_counter++;
				SetOfStates W = pairW.getFirst();
				Word word_of_W = pairW.getSecond();

				if (flag_v) System.out.println("    considering MAX prefix '"+word_of_W+"' ("+max_counter+"/"+postIrev.getSetOfT(s).size()+")");
				if (flag_v) System.out.print("    PERIOD fix-point (" +call_V+ "): computing ..\r");
				
				nb_iterations[indexTMP] = 1;
				PostF postF = new PostF(s, W);
				while (postF.apply()) {nb_iterations[indexV]++; nb_iterations[indexTMP]++;}
				
				if (flag_v) System.out.println("    PERIOD fix-point (" +call_V+ "): done (" + nb_iterations[indexTMP] + " iterations, " +postF.size()+ " elements)");
				if (flag_c) extract_cardinals(postF.getCardinals(), indexV);

				int period_counter = 0;
				for (Pair<SetOfContexts, Word> pairV : postF.getSetOfT(s)) {period_counter++;
					SetOfContexts V = pairV.getFirst();
					Word word_of_V = pairV.getSecond();
					
					if (flag_v) System.out.println("    considering period '"+word_of_V+"' ("+period_counter+"/"+postF.getSetOfT(s).size()+")");
	
					// start relevant
					if (flag_o) { if (relevance_test(W, V) == false) continue;}
						for (Pair<SetOfStates, Word> pairU : postI.getSetOfT(s)) {
							SetOfStates U = pairU.getFirst();
							Word word_of_U = pairU.getSecond();
							
							if (U.smaller_than(W) == true) {membership_counter++;
								if (flag_v) System.out.println("      considering MIN prefix '"+word_of_U+"' smaller than the MAX prefix '"+word_of_W+"'");
								if (flag_v) System.out.print("      MEMBERSHIP ("+membership_counter+"): computing of "+word_of_U+" cycle{"+word_of_V+"} ..\r");
								boolean belongs = B.membership(U, word_of_V);
								if (flag_v) System.out.println("      MEMBERSHIP ("+membership_counter+"): done                                                     ");
								
								if (belongs == false) {
									witness = word_of_U + " cycle{" + word_of_V + "}";
									if (flag_v) System.out.println("      >> ABORT counter-example found: "+witness); 
									return false;
								}
							}
						}
					// end relevant
				}
			}
		}
		return true;
	}
	
	private static boolean relevance_test (SetOfStates W, SetOfContexts V) {
		for (SetOfStates set : V.getFirst().values())
			if (set.smaller_than(W) == false) return false;
		return true;
	}
	
	private static void extract_cardinals (Triplet<Integer, Integer, Integer> triplet, int index) {
		if (min_cardinal[index] < 0 || min_cardinal[index] > triplet.getFirst()) min_cardinal[index] = triplet.getFirst();
		if (max_cardinal[index] < triplet.getSecond()) max_cardinal[index] = triplet.getSecond();
		all_cardinal[index] += triplet.getThird();
	}
	
}


