
import java.nio.file.Path;
import java.util.HashSet;

import automata.BuchiAutomaton;


public class Test {
	static String[] tests = {
			"example",
			"All_Sturmian_words_contain_cubes",
			"The_lazy_Ostrowski_representation_is_unique",
			"Specal_factors_are_unique",
			"All_positive_numbers_have_a_predecessor",
			"All_Sturmian_words_start_with_arbitarily_long_palindromes",
			"peterson",
			"BuchiCegarLoopAbstraction",
			"bigb",
	};
	
	
	
	public static void main(String[] args) throws Exception {
		if (args.length != 1) throw new Error("The program needs the path directory of the set of samples as a parameter");
		
		System.out.println("################\n\nCANDLENUT TEST");
		
		for (String test : tests) {
			System.out.println("\n¨¨¨¨¨¨¨¨¨¨\n" + test);
			
			Path fileA = Path.of(args[0] + test + "_SUBSET.ba");
			BuchiAutomaton A = new BuchiAutomaton(fileA, new HashSet<>());
			
			Path fileB = Path.of(args[0] + test + "_SUPERSET.ba");
			BuchiAutomaton B = new BuchiAutomaton(fileB, A.getAlphabet());

			Main.witness="";
			System.out.println("  A subset of B: " + Main.inclusion(A, B) + "(witness:" + Main.witness + ")");
			Main.witness="";
			System.out.println("  B subset of A: " + Main.inclusion(A, B) + "(witness:" + Main.witness + ")");
		}
		System.out.println("\n################");
	}
}


