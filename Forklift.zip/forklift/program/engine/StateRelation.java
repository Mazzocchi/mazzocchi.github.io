package engine;

import automata.*;
import tuples.*;
import java.util.*;


public final class StateRelation
extends HashMap<State, SetOfStates>
implements QuasiOrder<StateRelation>, Iterable<Pair<State, State>> {

	public void add (State initB, State stateB) {
		Set<State> set = computeIfAbsent(initB, k -> new SetOfStates());
		set.add(stateB);	
	}
	
	public boolean addAll (State initB, Collection<State> stateB) {
		Set<State> set = computeIfAbsent(initB, k -> new SetOfStates());
		return set.addAll(stateB);
	}
	
	public boolean contains (State initB, State stateB) {
		Set<State> set = get(initB);
		if (set == null) return false;
		return set.contains(stateB);
	}

	public boolean smaller_than (StateRelation rel) {
		for (State fromB : keySet()) {
			if (rel.get(fromB) == null) return false;
			for (State state : get(fromB))
				if (rel.get(fromB).contains(state) == false) return false;
		}
		return true;
	}

	public String toString() {
		StringJoiner outersj = new StringJoiner(";", "{", "}" );
		for (Pair<State, State> pair : this) {
			StringJoiner sj = new StringJoiner(",", "(", ")" );
			sj.add(pair.getFirst().toString());
			sj.add(pair.getSecond().toString());
			outersj.add(sj.toString());
		}
		return outersj.toString();
	}


	public Iterator<Pair<State, State>> iterator() {
		return new StateRelationIterator(this);
	}

	private static class EmptyIterator<T>
	implements Iterator<T> {
		EmptyIterator () {}
		public boolean hasNext() {return false;}
		public T next() {return null;}
	}

	public static class StateRelationIterator
	implements Iterator<Pair<State, State>> {

		private final StateRelation rel;
		private State state_key = null;
		Iterator<State> iter_key;
		Iterator<State> iter_value;

		public StateRelationIterator (StateRelation rel) {
			this.rel = rel;
			iter_key = rel.keySet().iterator();
			iter_value = new EmptyIterator<>();
		}

		public boolean hasNext() {
			if (iter_value.hasNext()) return true;
			if (iter_key.hasNext()) {
				state_key = iter_key.next();
				iter_value = rel.get(state_key).iterator();
				return hasNext();
			}				
			return false;
		}

		public Pair<State, State> next() {
			if (this.hasNext()) return new Pair<>(state_key, iter_value.next());
			return null;
		}
	}
}

	
	