package engine;

public interface QuasiOrder<T> {
	boolean smaller_than (T set);
}