package engine;

import tuples.Triplet;

public interface QuasiOrder<T> {
	boolean smaller_than (T set);
	Triplet<Integer, Integer, Integer> getCardinals ();
}