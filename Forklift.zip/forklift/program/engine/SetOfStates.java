package engine;

import automata.*;
import tuples.Triplet;

import java.util.*;
import java.util.stream.Collectors;


public class SetOfStates extends HashSet<State> implements QuasiOrder<SetOfStates> {

	public Triplet<Integer, Integer, Integer> getCardinals () {
		return new Triplet<>(this.size(), this.size(), 1);
	}
	
	public boolean smaller_than (SetOfStates set) { return set.containsAll(this); }
	
	public String toString() {
		return this.stream().map(State::toString).collect(Collectors.joining(";", "{", "}"));
	}
}

