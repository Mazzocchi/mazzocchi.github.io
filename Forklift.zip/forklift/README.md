# Forklift

Forklift is an inclusion checker for Büchi automata.  You pass two Büchi
automata in BA format described
[here](http://languageinclusion.org/doku.php?id=tools#the_ba_format) and, upon
termination, it tells you whether the language of the first Büchi automata is
contained into the second. 

# Compilation

Running `make` produces a `forklift.jar` file.

# Running

Running `java -jar forklift.jar sub.ba sup.ba` returns whether the language of
the Büchi automata `sub.ba` is included in that of `sup.ba`.

Run `java -jar forklift.jar` for more details about stats, verbose output,
witness of non-inclusion,… 
